package com.example.xauusd;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>" +
          "<style>body{margin:0;background:#0b1020;color:#fff;font-family:Arial}header{padding:18px;font-size:22px;font-weight:bold}p{padding:0 18px;color:#aab4ca}</style></head><body>" +
          "<header>XAUUSD · Gold</header><p>TradingView chart (OANDA feed). This is not XM broker pricing.</p>" +
          "<div class='tradingview-widget-container'><div id='tradingview_chart'></div></div>" +
          "<script src='https://s3.tradingview.com/tv.js'></script><script>" +
          "new TradingView.widget({autosize:true,symbol:'OANDA:XAUUSD',interval:'5',timezone:'Asia/Kolkata',theme:'dark',style:'1',locale:'en',enable_publishing:false,allow_symbol_change:true,container_id:'tradingview_chart',studies:['RSI@tv-basicstudies','MACD@tv-basicstudies','BB@tv-basicstudies','MASimple@tv-basicstudies']});" +
          "</script></body></html>";
        web.loadDataWithBaseURL("https://www.tradingview.com/", html, "text/html", "UTF-8", null);
    }
}
