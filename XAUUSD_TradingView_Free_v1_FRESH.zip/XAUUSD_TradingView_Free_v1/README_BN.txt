XAUUSD TradingView Free v1

এটি Android Studio project source; সরাসরি ইনস্টল করার APK নয়।
চার্টে OANDA:XAUUSD TradingView widget ব্যবহার করা হয়েছে। এটি XM-এর নিজস্ব quote/feed নয় এবং TradingView-এর ডেটা availability/delay প্রযোজ্য।

APK তৈরি করতে Android Studio-তে এই ফোল্ডার খুলে Gradle Sync করুন, তারপর Build > Build APK(s) নির্বাচন করুন।
এই প্রজেক্টে কোনো XM login, broker API key বা trade execution নেই।
